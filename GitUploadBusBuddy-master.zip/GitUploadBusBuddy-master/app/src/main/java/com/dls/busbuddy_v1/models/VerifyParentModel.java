package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

public class VerifyParentModel {

    @SerializedName("student_id")
    private int student_id;
    @SerializedName("school_id")
    private int school_id;
    @SerializedName("f_name")
    private String f_name;
    @SerializedName("l_name")
    private String l_name;
    @SerializedName("p_mobile")
    private String p_mobile;
    @SerializedName("s_mobile")
    private String s_mobile;
    @SerializedName("class_id")
    private String class_id;
    @SerializedName("section_id")
    private String section_id;

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public int getSchool_id() {
        return school_id;
    }

    public void setSchool_id(int school_id) {
        this.school_id = school_id;
    }

    public String getF_name() {
        return f_name;
    }

    public void setF_name(String f_name) {
        this.f_name = f_name;
    }

    public String getL_name() {
        return l_name;
    }

    public void setL_name(String l_name) {
        this.l_name = l_name;
    }

    public String getP_mobile() {
        return p_mobile;
    }

    public void setP_mobile(String p_mobile) {
        this.p_mobile = p_mobile;
    }

    public String getS_mobile() {
        return s_mobile;
    }

    public void setS_mobile(String s_mobile) {
        this.s_mobile = s_mobile;
    }

    public String getClass_id() {
        return class_id;
    }

    public void setClass_id(String class_id) {
        this.class_id = class_id;
    }

    public String getSection_id() {
        return section_id;
    }

    public void setSection_id(String section_id) {
        this.section_id = section_id;
    }

    @Override
    public String toString() {
        return "VerifyParentModel{" +
                "student_id=" + student_id +
                ", school_id=" + school_id +
                ", f_name='" + f_name + '\'' +
                ", l_name='" + l_name + '\'' +
                ", p_mobile='" + p_mobile + '\'' +
                ", s_mobile='" + s_mobile + '\'' +
                ", class_id='" + class_id + '\'' +
                ", section_id='" + section_id + '\'' +
                '}';
    }
}
