package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class NotifyHistoryResponse {

    @SerializedName("statusCode")
    private String statusCode;
    @SerializedName("d_status")
    private String d_status;
    @SerializedName("j_data")
    private List<NotifyList> j_data;

}
