package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SchoolDDResponseModel extends StatusMsgModel{

    @SerializedName("j_data")
    private List<SchoolsListModel> j_data;

    public List<SchoolsListModel> getJ_data() {
        return j_data;
    }

    public void setJ_data(List<SchoolsListModel> j_data) {
        this.j_data = j_data;
    }

    @Override
    public String toString() {
        return "SchoolDDResponseModel{" +
                "j_data=" + j_data +
                '}';
    }
}
