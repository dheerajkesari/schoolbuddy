package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

public class GetBusLocationData {
    @SerializedName("busno")
    private String busno;

    @SerializedName("speed")
    private String speed;

    @SerializedName("dt_tracker")
    private String dt_tracker;

    @SerializedName("latitude")
    private String latitude;

    @SerializedName("longitude")
    private String longitude;

    public void setBusno(String busno) {
        this.busno = busno;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public String getDt_tracker() {
        return dt_tracker;
    }

    public void setDt_tracker(String dt_tracker) {
        this.dt_tracker = dt_tracker;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getBusno() {
        return busno;
    }

    @Override
    public String toString() {
        return "GetBusLocationData{" +
                "busno='" + busno + '\'' +
                ", speed='" + speed + '\'' +
                ", dt_tracker='" + dt_tracker + '\'' +
                ", latitude='" + latitude + '\'' +
                ", longitude='" + longitude + '\'' +
                '}';
    }
}
