package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class VerifyParentResponseModel extends StatusMsgModel {
    @SerializedName("school_id")
    private String school_id;

    @SerializedName("p_mobile")
    private String p_mobile;

    @SerializedName("parent_type")
    private String parent_type;

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getP_mobile() {
        return p_mobile;
    }

    public void setP_mobile(String p_mobile) {
        this.p_mobile = p_mobile;
    }

    public String getParent_type() {
        return parent_type;
    }

    public void setParent_type(String parent_type) {
        this.parent_type = parent_type;
    }

    @SerializedName("data_j")
    private List<VerifyParentModel> data_j;

    public List<VerifyParentModel> getData_j() {
        return data_j;
    }

    public void setData_j(List<VerifyParentModel> data_j) {
        this.data_j = data_j;
    }

    @Override
    public String toString() {
        return "VerifyParentResponseModel{" +
                "school_id='" + school_id + '\'' +
                ", p_mobile='" + p_mobile + '\'' +
                ", parent_type='" + parent_type + '\'' +
                ", data_j=" + data_j +
                '}';
    }

    //    @Override
//    public String toString() {
//        return "VerifyParentResponseModel{" +
//                "parent_type='" + parent_type + '\'' +
//                ", data_j=" + data_j +
//                '}';
//    }
}
