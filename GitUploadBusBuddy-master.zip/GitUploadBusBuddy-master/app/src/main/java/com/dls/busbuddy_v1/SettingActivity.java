package com.dls.busbuddy_v1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Activity;
import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class SettingActivity extends AppCompatActivity {

    private Switch NotifyBtn;
    private static final String CHECK_OP_NO_THROW = "checkOpNoThrow";
    private static final String OP_POST_NOTIFICATION = "OP_POST_NOTIFICATION";
    private Object JSONObject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        NotifyBtn = findViewById(R.id.SwitchNotificationSound);
        Boolean Noti = NotificationManagerCompat.getEnabledListenerPackages (getApplicationContext()).contains(getApplicationContext().getPackageName());
        System.out.println("@@@@   @@@@   Notification :: "+Noti);
//        makeText(, "SImpy", 1000);
//        if (showNotifcation) {
//
//        }
       // notificationSound();
    }

    public static void makeText(Context mContext, String message, int time) {
        if (isNotificationEnabled(mContext)) {
            //Show Toast message
            Toast.makeText(mContext, message, time).show();
        } else {
            // Or show own custom alert dialog
            showCustomAlertDialog(mContext, message);
        }
    }

    private static boolean isNotificationEnabled(Context mContext) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            AppOpsManager mAppOps = (AppOpsManager) mContext.getSystemService(Context.APP_OPS_SERVICE);
            ApplicationInfo appInfo = mContext.getApplicationInfo();
            String pkg = mContext.getApplicationContext().getPackageName();
            int uid = appInfo.uid;
            Class appOpsClass;
            try {
                appOpsClass = Class.forName(AppOpsManager.class.getName());
                Method checkOpNoThrowMethod =
                        appOpsClass.getMethod(CHECK_OP_NO_THROW, Integer.TYPE, Integer.TYPE, String.class);

                Field opPostNotificationValue = appOpsClass.getDeclaredField(OP_POST_NOTIFICATION);
                int value = (int) opPostNotificationValue.get(Integer.class);
                return ((int) checkOpNoThrowMethod.invoke(mAppOps, value, uid,
                        pkg) == AppOpsManager.MODE_ALLOWED);
            } catch (ClassNotFoundException | NoSuchMethodException | NoSuchFieldException
                    | InvocationTargetException | IllegalAccessException ex) {
                //Utils.logExceptionCrashLytics(ex);
            }
            return false;
        } else {
            return false;
        }
    }

    private static void showCustomAlertDialog(Context mContext, String message) {
        if (!(mContext instanceof Activity && ((Activity)mContext).isFinishing())) {
            AlertDialog.Builder mBuilder = new AlertDialog.Builder(mContext);
            mBuilder.setMessage(message);
//            mBuilder.setPositiveButton(mContext.getString(R.string.ok),
//                    new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            dialog.dismiss();
//                        }
//                    });
            mBuilder.setCancelable(true);
            AlertDialog alertDialog = mBuilder.create();
            alertDialog.show();
        }
    }
    public void notificationSound(){
        // define sound URI, the sound to be played when there's a notification
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        // intent triggered, you can add other intent for other actions
        Intent intent = new Intent(SettingActivity.this, SettingActivity.class);
        PendingIntent pIntent = PendingIntent.getActivity(SettingActivity.this, 0, intent, 0);

        // this is it, we'll build the notification!
        // in the addAction method, if you don't want any icon, just set the first param to 0
        Notification mNotification = new Notification.Builder(this)

                .setContentTitle("New Post!")
                .setContentText("Here's an awesome update for you!")
                .setSmallIcon(R.drawable.main_logo)
                .setContentIntent(pIntent)
                .setSound(soundUri)

//                .addAction(R.drawable.main_logo, "View", pIntent)
//                .addAction(0, "Remind", pIntent)

                .build();

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // If you want to hide the notification after it was selected, do the code below
        // myNotification.flags |= Notification.FLAG_AUTO_CANCEL;

        notificationManager.notify(0, mNotification);
//        try {
//            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//            Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
//            r.play();
//        } catch (Exception e){
//            e.printStackTrace();
//        }
//        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

//        Intent intent = new Intent(TemperatureActivity.this,TemperatureActivity.class);
//        PendingIntent pIntent = PendingIntent.getActivity(TemperatureActivity.this, 0, intent, 0);
//
//        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//        Notification mNotification = new Notification.Builder(getApplicationContext())
//                .setContentTitle("Alert")
//                .setContentText("Body temperature is more than normal")
//                .setSmallIcon(R.drawable.care)
//                .setContentIntent(pIntent)
//                .setSound(soundUri)
//                .build();
//
//
//        mNotification.flags |= Notification.FLAG_AUTO_CANCEL;
//
//        notificationManager.notify(0, mNotification);
    } //notificationSound ends here
    public void notificationVibration(){
        try {

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
