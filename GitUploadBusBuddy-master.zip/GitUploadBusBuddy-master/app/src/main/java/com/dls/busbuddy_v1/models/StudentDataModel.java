package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

public class StudentDataModel {
    @SerializedName("school_id")
    private String school_id;
    @SerializedName("student_id")
    private String student_id;
    @SerializedName("card_id")
    private String card_id;
    @SerializedName("f_name")
    private String f_name;
    @SerializedName("l_name")
    private String l_name;
    @SerializedName("p_mobile")
    private String p_mobile;
    @SerializedName("s_mobile")
    private String s_mobile;
    @SerializedName("class_id")
    private String class_id;
    @SerializedName("section_id")
    private String section_id;
    @SerializedName("bus_imei_no_m")
    private String bus_imei_no_m;
    @SerializedName("bus_imei_no_e")
    private String bus_imei_no_e;
    @SerializedName("trip_name_m")
    private String trip_name_m;
    @SerializedName("trip_name_e")
    private String trip_name_e;
    @SerializedName("user_landmark")
    private String user_landmark;
    @SerializedName("user_lat")
    private String user_lat;

    @SerializedName("user_lng")
    private String user_lng;

    @SerializedName("pay_status")
    private int pay_status;

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getStudent_id() {
        return student_id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    public String getCard_id() {
        return card_id;
    }

    public void setCard_id(String card_id) {
        this.card_id = card_id;
    }

    public String getF_name() {
        return f_name;
    }

    public void setF_name(String f_name) {
        this.f_name = f_name;
    }

    public String getL_name() {
        return l_name;
    }

    public void setL_name(String l_name) {
        this.l_name = l_name;
    }

    public String getP_mobile() {
        return p_mobile;
    }

    public void setP_mobile(String p_mobile) {
        this.p_mobile = p_mobile;
    }

    public String getS_mobile() {
        return s_mobile;
    }

    public void setS_mobile(String s_mobile) {
        this.s_mobile = s_mobile;
    }

    public String getClass_id() {
        return class_id;
    }

    public void setClass_id(String class_id) {
        this.class_id = class_id;
    }

    public String getSection_id() {
        return section_id;
    }

    public void setSection_id(String section_id) {
        this.section_id = section_id;
    }

    public String getBus_imei_no_m() {
        return bus_imei_no_m;
    }

    public void setBus_imei_no_m(String bus_imei_no_m) {
        this.bus_imei_no_m = bus_imei_no_m;
    }

    public String getBus_imei_no_e() {
        return bus_imei_no_e;
    }

    public void setBus_imei_no_e(String bus_imei_no_e) {
        this.bus_imei_no_e = bus_imei_no_e;
    }

    public String getTrip_name_m() {
        return trip_name_m;
    }

    public void setTrip_name_m(String trip_name_m) {
        this.trip_name_m = trip_name_m;
    }

    public String getTrip_name_e() {
        return trip_name_e;
    }

    public void setTrip_name_e(String trip_name_e) {
        this.trip_name_e = trip_name_e;
    }

    public String getUser_landmark() {
        return user_landmark;
    }

    public void setUser_landmark(String user_landmark) {
        this.user_landmark = user_landmark;
    }

    public String getUser_lat() {
        return user_lat;
    }

    public void setUser_lat(String user_lat) {
        this.user_lat = user_lat;
    }

    public String getUser_lng() {
        return user_lng;
    }

    public void setUser_lng(String user_lng) {
        this.user_lng = user_lng;
    }

    public int getPay_status() {
        return pay_status;
    }

    public void setPay_status(int pay_status) {
        this.pay_status = pay_status;
    }

    @Override
    public String toString() {
        return "StudentDataModel{" +
                "school_id='" + school_id + '\'' +
                ", student_id='" + student_id + '\'' +
                ", card_id='" + card_id + '\'' +
                ", f_name='" + f_name + '\'' +
                ", l_name='" + l_name + '\'' +
                ", p_mobile='" + p_mobile + '\'' +
                ", s_mobile='" + s_mobile + '\'' +
                ", class_id='" + class_id + '\'' +
                ", section_id='" + section_id + '\'' +
                ", bus_imei_no_m='" + bus_imei_no_m + '\'' +
                ", bus_imei_no_e='" + bus_imei_no_e + '\'' +
                ", trip_name_m='" + trip_name_m + '\'' +
                ", trip_name_e='" + trip_name_e + '\'' +
                ", user_landmark='" + user_landmark + '\'' +
                ", user_lat='" + user_lat + '\'' +
                ", user_lng='" + user_lng + '\'' +
                ", pay_status=" + pay_status +
                '}';
    }
}
