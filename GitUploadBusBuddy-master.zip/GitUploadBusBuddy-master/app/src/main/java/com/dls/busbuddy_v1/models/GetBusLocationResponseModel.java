package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

public class GetBusLocationResponseModel {

    @SerializedName("op")
    private String op;

    @SerializedName("school_id")
    private String school_id;

    @SerializedName("imei_no")
    private String imei_no;

    @SerializedName("message")
    private String message;

    @SerializedName("j_data")
    private GetBusLocationData j_data;

    public void setOp(String op) {
        this.op = op;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getImei_no() {
        return imei_no;
    }

    public void setImei_no(String imei_no) {
        this.imei_no = imei_no;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public GetBusLocationData getJ_data() {
        return j_data;
    }

    public void setJ_data(GetBusLocationData j_data) {
        this.j_data = j_data;
    }

    public String getOp() {
        return op;
    }

    @Override
    public String toString() {
        return "GetBusLocationResponseModel{" +
                "op='" + op + '\'' +
                ", school_id='" + school_id + '\'' +
                ", imei_no='" + imei_no + '\'' +
                ", message='" + message + '\'' +
                ", j_data=" + j_data +
                '}';
    }
}
