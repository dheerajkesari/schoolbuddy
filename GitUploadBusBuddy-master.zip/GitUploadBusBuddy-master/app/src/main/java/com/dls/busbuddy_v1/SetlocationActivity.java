package com.dls.busbuddy_v1;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.dls.busbuddy_v1.models.GetStudentResponseModel;
import com.dls.busbuddy_v1.models.SetDroppointResponseModel;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.GeoDataClient;

import com.google.android.gms.location.places.PlaceDetectionClient;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SetlocationActivity extends ThirdActivity implements OnMapReadyCallback {

    private static final String TAG = SetlocationActivity.class.getSimpleName();
    private static final String KEY_CAMERA_POSITION = "camera_position";
    private static final String KEY_LOCATION = "location";
    private GeoDataClient mGeoDataClient;
    private PlaceDetectionClient mPlaceDetectionClient;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    private GoogleMap mMap;
    private String address;
    private Location mLastKnownLocation;
    private CameraPosition mCameraPosition;
    private GoogleMap.OnCameraIdleListener camListener;
    private final LatLng mDefaultLocation = new LatLng(-33.8523341, 151.2106085);
    //private final LatLng myCoordinates = new LatLng(-34,151);
    private static final int DEFAULT_ZOOM = 15;
    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
    private boolean mLocationPermissionGranted;
    Marker marker1 = null;
    ProgressDialog progressDialog;
    UrlCallInterface baseUrl = BaseUrlInterface.postBaseUrl.create(com.dls.busbuddy_v1.UrlCallInterface.class);
    private EditText Landmark_text;
    public static String LndMrk;
    public static String setLat;
    public static String setLng;
    public Button SetdropBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Retrieve location and camera position from saved instance state.
        if (savedInstanceState != null) {
            mLastKnownLocation = savedInstanceState.getParcelable(KEY_LOCATION);
            mCameraPosition = savedInstanceState.getParcelable(KEY_CAMERA_POSITION);
        }
//        setContentView(R.layout.activity_setlocation);
        View rootView = getLayoutInflater().inflate(R.layout.activity_setlocation, frameLayout);

        System.out.println("Main activity Starts here");
        mGeoDataClient = Places.getGeoDataClient(this, null);
        mPlaceDetectionClient = Places.getPlaceDetectionClient(this, null);
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        SetdropBtn = findViewById(R.id.btn_submitDroppoint);
        SetdropBtn.setEnabled(true);
        SetdropBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Button Clicked");

                Bundle bundle = getIntent().getExtras();
                final String ParentMobileno = bundle.getString("Pmobile");
                final String SchoolID = bundle.getString("SchoolID");
                Landmark_text = findViewById(R.id.etLandmark);

                LndMrk = Landmark_text.getText().toString();
                System.out.println("btn clicked Set Drop Point");

                SetDroppointResponseModel dropPointObj = new SetDroppointResponseModel();
                dropPointObj.setOp("updateuserdrops");
                dropPointObj.setSchool_id(SchoolID);
                dropPointObj.setStudent_id("336");
                dropPointObj.setUser_lat(setLat);
                dropPointObj.setUser_lng(setLng);
                dropPointObj.setUser_landmark(LndMrk);

                System.out.println("dropPointObj  before:::: " + dropPointObj);
                Call<SetDroppointResponseModel> droppointService = baseUrl.setdropPost(dropPointObj);
                droppointService.enqueue(new Callback<SetDroppointResponseModel>() {
                    @Override
                    public void onResponse(Call<SetDroppointResponseModel> call, Response<SetDroppointResponseModel> response) {
                        try {
                            if (response.isSuccessful()) {
                                SetDroppointResponseModel setDroppointResponseModel = new SetDroppointResponseModel();
                                System.out.println("  msg :: " +setDroppointResponseModel.getMsg());
                                JSONObject SetDroppointResponse = new JSONObject(new Gson().toJson(response.body()));
//                                System.out.println("SUccessss   msg :: " + SetDroppointResponse.get("msg"));
                                String message = SetDroppointResponse.get("msg").toString();
                                if (message.equals("success")){
                                    AlertDialog alertDialog = new AlertDialog.Builder(SetlocationActivity.this).create();
                                    alertDialog.setMessage("Drop Point Successfully set");
                                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    dialog.dismiss();
                                                    Bundle b = new Bundle();
                                                    Intent intent = new Intent(SetlocationActivity.this, ThirdActivity.class);
                                                    b.putString("Pmobile", ParentMobileno);
                                                    b.putString("SchoolId", SchoolID);
                                                    intent.putExtras(b);
                                                    startActivity(intent);
                                                }
                                            });
                                    alertDialog.show();
                                }else{
                                    System.out.println("Failed to Submit");
                                }

                            } else {
                                System.out.println("Failure    msg :: ");

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void onFailure(Call<SetDroppointResponseModel> call, Throwable t) {
                        System.out.println("HTTP Service Error ::  "+t.getMessage());
                        progressDialog.dismiss();
                        AlertDialog alertDialog = new AlertDialog.Builder(SetlocationActivity.this).create();
                        alertDialog.setMessage("No Internet");
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                    }
                });
            }
        });

    }


    @Override
    public void onMapReady(GoogleMap map) {
        mMap = map;
        Button btn = (Button) findViewById(R.id.currbtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("On click response");
                getLocationPermission();
                getDeviceLocation();
                updateLocationUI();
            }
        });
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (mMap != null) {
            outState.putParcelable(KEY_CAMERA_POSITION, mMap.getCameraPosition());
            outState.putParcelable(KEY_LOCATION, mLastKnownLocation);
            super.onSaveInstanceState(outState);
        }
    }

    private void configureCameraIdle(final Marker movemarker ) {
        progressDialog = new ProgressDialog(SetlocationActivity.this);
        progressDialog.setMessage("Please Wait");
        progressDialog.setCancelable(false);
        progressDialog.show();

        mMap.setOnCameraIdleListener(new GoogleMap.OnCameraIdleListener() {
            @Override
            public void onCameraIdle() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //get latlng at the center by calling
                        LatLng midLatLng = mMap.getCameraPosition().target;
                        System.out.println("LatLng  @@@@:" + midLatLng);
                        movemarker.setPosition(midLatLng);
                        midLatLng = movemarker.getPosition();
                        Geocoder geocoder = new Geocoder(SetlocationActivity.this);
                        try {
                            List<Address> addressList = geocoder.getFromLocation(midLatLng.latitude, midLatLng.longitude, 1);
                            String address = addressList.get(0).getAddressLine(0);
                            System.out.println("ADDRESSS    ::: "+address);
                            TextView txtadd = (TextView) findViewById(R.id.fulladdress);
                            progressDialog.dismiss();
                            txtadd.setText("ADDRESS:" + address);
                            setLat = String.valueOf(midLatLng.latitude);
                            setLng = String.valueOf(midLatLng.longitude);
                            //setDropMethod(String.valueOf(midLatLng.latitude), String.valueOf(midLatLng.longitude));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } //run() ends here
                });
            }
        });
    }


    public void setDropMethod(final String latitude, final String longitude){
//        Bundle bundle = getIntent().getExtras();
//        final String ParentMobileno = bundle.getString("Pmobile");
//        final String SchoolID = bundle.getString("SchoolId");
//        Landmark_text = findViewById(R.id.etLandmark);
//
//        LndMrk = Landmark_text.getText().toString();
//        System.out.println("btn clicked Set Drop Point");
//
//        SetDroppointResponseModel dropPointObj = new SetDroppointResponseModel();
//        dropPointObj.setOp("updateuserdrops");
//        dropPointObj.setSchool_id(SchoolID);
//        dropPointObj.setStudent_id(ParentMobileno);
//        dropPointObj.setUser_lat(latitude);
//        dropPointObj.setUser_lng(longitude);
//        dropPointObj.setUser_landmark(LndMrk);
//
//        System.out.println("dropPointObj  before:::: " + dropPointObj);
//        Call<SetDroppointResponseModel> droppointService = baseUrl.setdropPost(dropPointObj);
//        droppointService.enqueue(new Callback<SetDroppointResponseModel>() {
//            @Override
//            public void onResponse(Call<SetDroppointResponseModel> call, Response<SetDroppointResponseModel> response) {
//                try {
//                    if (response.isSuccessful()) {
//                        JSONObject SetDroppointResponse = new JSONObject(new Gson().toJson(response.body()));
//                        System.out.println("SUccessss   msg :: " + SetDroppointResponse);
//
//                    } else {
//                        System.out.println("Failure    msg :: ");
//
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//
//            }
//            @Override
//            public void onFailure(Call<SetDroppointResponseModel> call, Throwable t) {
//                System.out.println("HTTP Service Error ::  "+t.getMessage());
//                progressDialog.dismiss();
//                AlertDialog alertDialog = new AlertDialog.Builder(SetlocationActivity.this).create();
//                alertDialog.setMessage("No Internet");
//                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
//                        new DialogInterface.OnClickListener() {
//                            public void onClick(DialogInterface dialog, int which) {
//                                dialog.dismiss();
//                            }
//                        });
//                alertDialog.show();
//            }
//        });
    }


    public class getAddress extends AsyncTask<String, String, String> {
        private LatLng myCoordinates= new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude());
        //private String address;

        @Override
        protected void onPostExecute(String address) {
            super.onPostExecute(address);
            TextView txtadd = (TextView) findViewById(R.id.fulladdress);
            txtadd.setText("ADDRESS:"+address);
            System.out.println("ADDRESS:"+address);
        }

        @Override
        protected String doInBackground(String... strings) {
            String address = "";
            Geocoder geocoder = new Geocoder(SetlocationActivity.this, Locale.getDefault());
            try {
                List<Address> addresses = geocoder.getFromLocation(myCoordinates.latitude, myCoordinates.longitude, 1);
                address = addresses.get(0).getAddressLine(0);
                System.out.println("@@@@@@@@@@@@@@@@@@@@ADDRESS:" + address);
                Log.d("mytag", "Address:" + address);
                Log.d("mytag", "Complete Address:" + addresses.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return address;
        }
    }

    private void getDeviceLocation() {

        try {
            if (mLocationPermissionGranted) {
                Task<Location> locationResult = mFusedLocationProviderClient.getLastLocation();
                locationResult.addOnCompleteListener(this, new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if (task.isSuccessful()) {
                            // Set the map's camera position to the current location of the device.
                            mLastKnownLocation = task.getResult();
                            LatLng myCoordinates = new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude());
                            //mMap.addMarker(new MarkerOptions().position(myCoordinates).title("current position"));
                            marker1 = mMap.addMarker(new MarkerOptions().position(myCoordinates));
                            //marker1.setPosition(myCoordinates);
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(myCoordinates, DEFAULT_ZOOM));
                            new getAddress().execute();
                            configureCameraIdle(marker1);
                            System.out.println("MYCOORDINATES:"+myCoordinates);
                        } else {
                            Log.d(TAG, "Current location is null. Using defaults.");
                            Log.e(TAG, "Exception: %s", task.getException());
                            mMap.moveCamera(CameraUpdateFactory
                                    .newLatLngZoom(mDefaultLocation, DEFAULT_ZOOM));
                            mMap.getUiSettings().setMyLocationButtonEnabled(false);
                        }
                    }
                });
            }
        } catch (SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    private void getLocationPermission() {
        System.out.println("permission granting");
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;
            System.out.println("mLocationPermissionGranted:"+mLocationPermissionGranted);
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        mLocationPermissionGranted = false;
        switch (requestCode) {
            case PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mLocationPermissionGranted = true;
                }
            }
        }
        updateLocationUI();
    }

    private void updateLocationUI() {
        if (mMap == null) {
            return;
        }
        try {
            if (mLocationPermissionGranted) {
                mMap.setMyLocationEnabled(true);
                mMap.getUiSettings().setMyLocationButtonEnabled(false);
            } else {
                mMap.setMyLocationEnabled(false);
                mMap.getUiSettings().setMyLocationButtonEnabled(false);
                mLastKnownLocation = null;
                getLocationPermission();
            }
        } catch (SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }
}
