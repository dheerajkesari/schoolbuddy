package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

public class VersionModel {

    @SerializedName("op")
    private String op;
    @SerializedName("version")
    private String version;
    @SerializedName("date")
    private String date;

    public String getOp() {
        return op;
    }

    public void setOp(String op) {
        this.op = op;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "VersionModel{" +
                "op='" + op + '\'' +
                ", version='" + version + '\'' +
                ", date='" + date + '\'' +
                '}';
    }
}
