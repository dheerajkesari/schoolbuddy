package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

public class NotificationDataResponse {

    @SerializedName("p_mobile")
    private String p_mobile;

    @SerializedName("msg")
    private String msg;

    @SerializedName("bus_imei_no")
    private String bus_imei_no;

    @SerializedName("notification_tt")
    private String notification_tt;

    @SerializedName("bus_no")
    private String bus_no;

    @SerializedName("s_name")
    private String s_name;

    @SerializedName("school_id")
    private String school_id;

    @SerializedName("student_id")
    private String student_id;

    public String getP_mobile() {
        return p_mobile;
    }

    public void setP_mobile(String p_mobile) {
        this.p_mobile = p_mobile;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getBus_imei_no() {
        return bus_imei_no;
    }

    public void setBus_imei_no(String bus_imei_no) {
        this.bus_imei_no = bus_imei_no;
    }

    public String getNotification_tt() {
        return notification_tt;
    }

    public void setNotification_tt(String notification_tt) {
        this.notification_tt = notification_tt;
    }

    public String getBus_no() {
        return bus_no;
    }

    public void setBus_no(String bus_no) {
        this.bus_no = bus_no;
    }

    public String getS_name() {
        return s_name;
    }

    public void setS_name(String s_name) {
        this.s_name = s_name;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getStudent_id() {
        return student_id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    @Override
    public String toString() {
        return "NotificationDataResponse{" +
                "p_mobile='" + p_mobile + '\'' +
                ", msg='" + msg + '\'' +
                ", bus_imei_no='" + bus_imei_no + '\'' +
                ", notification_tt='" + notification_tt + '\'' +
                ", bus_no='" + bus_no + '\'' +
                ", s_name='" + s_name + '\'' +
                ", school_id='" + school_id + '\'' +
                ", student_id='" + student_id + '\'' +
                '}';
    }
}
