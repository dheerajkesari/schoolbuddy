package com.dls.busbuddy_v1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.dls.busbuddy_v1.models.GetAllNotificationResponseModel;
import com.dls.busbuddy_v1.models.NotificationDataResponse;
import com.dls.busbuddy_v1.models.SchoolDDResponseModel;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationActivity extends ThirdActivity {

    ProgressDialog progressDialog;
    UrlCallInterface baseUrl = BaseUrlInterface.postBaseUrl.create(com.dls.busbuddy_v1.UrlCallInterface.class);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_notification);
        View rootView = getLayoutInflater().inflate(R.layout.activity_notification, frameLayout);
        Bundle bundle = getIntent().getExtras();

        final String ParentMobileno = bundle.getString("Pmobile");
        final String SchoolID = bundle.getString("SchoolID");
        getAllNotification(SchoolID, ParentMobileno);
    }

    private void getAllNotification(String SchoolID, String ParentMobileno) {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait ... ");
        progressDialog.setCancelable(false);
        progressDialog.show();

        GetAllNotificationResponseModel getAllNotifyService = new GetAllNotificationResponseModel();
        getAllNotifyService.setOp("notifMsg");
        getAllNotifyService.setSchool_id(SchoolID);
        getAllNotifyService.setP_mobile(ParentMobileno);
        Call<GetAllNotificationResponseModel> getNotifyPostService = baseUrl.GetNotificationlListPost(getAllNotifyService);
        getNotifyPostService.enqueue(new Callback<GetAllNotificationResponseModel>() {
            @Override
            public void onResponse(Call<GetAllNotificationResponseModel> call, Response<GetAllNotificationResponseModel> response) {
                JSONObject jsonObject = null;
                try {
                    if (response.isSuccessful()) {
                        GetAllNotificationResponseModel notiData = response.body();
//                        JSONObject notificationResponse = new JSONObject(new Gson().toJson(response.body()));
                       // System.out.println("notificationResponse   :: "+notificationResponse);
                        List<NotificationDataResponse> NotificationResponse = notiData.getJ_data();
                        System.out.println("GetAllNotificationResponseModel   :: "+NotificationResponse);


                        progressDialog.dismiss();
                        addNotification(NotificationResponse);
                    }else {
                        System.out.println("HTTP Service fail :::: "+ response.errorBody());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<GetAllNotificationResponseModel> call, Throwable t) {
                System.out.println("HTTP Service Error ::  "+t.getMessage());
                progressDialog.dismiss();
                AlertDialog alertDialog = new AlertDialog.Builder(NotificationActivity.this).create();
                alertDialog.setMessage("No Internet");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }
    private TextView getTextView(String id, String title, int color, int typeface, int bgColor) {
        TextView tv = new TextView(this);
        tv.setText(id);
        tv.setText(title.toUpperCase());
        tv.setTextColor(color);
        tv.setPadding(40, 40, 40, 40);
        tv.setTypeface(Typeface.DEFAULT, typeface);
        tv.setBackgroundColor(bgColor);
        tv.setLayoutParams(getLayoutParams());
        //tv.setOnClickListener(this);
        return tv;
    }


    private void addNotification(List jsonAry) {
        TableLayout tl = findViewById(R.id.tbl_notification);
        System.out.println("addNotification Data :::  "+jsonAry);
        try {
        for (int i = 0; i< jsonAry.size(); i++){
            List<NotificationDataResponse> notiRes = new ArrayList(jsonAry);
            System.out.println("NOTIFY Response  :: "+notiRes.get(i).getNotification_tt());
            System.out.println("NOTIFY Response  :: "+notiRes.get(i).getMsg());
            System.out.println("NOTIFY Response  :: "+notiRes.get(i).getBus_no());

            TableRow tr = new TableRow(this);
            tr.setLayoutParams(getLayoutParams());
            tr.addView(getTextView(notiRes.get(i).getNotification_tt(), notiRes.get(i).getMsg()+"  "+notiRes.get(i).getNotification_tt(), Color.BLACK, Typeface.NORMAL, Color.rgb(250, 225, 219)));//, jsonObj.toString()
            //tr.addView(getTextView(Integer.valueOf(jsonObj.getString("student_id")), "Track",Color.WHITE, Typeface.NORMAL, ContextCompat.getColor(this, R.color.colorAccent)));
            tl.addView(tr, getTblLayoutParams());
        }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @NonNull
    private TableRow.LayoutParams getLayoutParams() {
        TableRow.LayoutParams params = new TableRow.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(2, 0, 0, 2);
        return params;
    }
    @NonNull
    private TableLayout.LayoutParams getTblLayoutParams() {
        return new TableLayout.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT);
    }
}
