package com.dls.busbuddy_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.dls.busbuddy_v1.models.SchoolDDResponseModel;
import com.dls.busbuddy_v1.models.SchoolsListModel;
import com.dls.busbuddy_v1.models.VerifyParentModel;
import com.dls.busbuddy_v1.models.VerifyParentResponseModel;
import com.dls.busbuddy_v1.models.VersionModel;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity2 extends AppCompatActivity {

    private EditText Schoolname;
    private EditText Registermobile;
    private Button Verify;
    final Context context = this;
    private Spinner schoolListSpinner;
    ProgressDialog progressDialog;
    ListView list;
    public static String ddSchoolId;
    public static String appVer;
    public static String currentAppVersion;
    public static final Boolean isLastVersion = false;
    UrlCallInterface baseUrl = BaseUrlInterface.postBaseUrl.create(com.dls.busbuddy_v1.UrlCallInterface.class);

    public void getSchoolDD(){
        progressDialog = new ProgressDialog(MainActivity2.this);
        progressDialog.setMessage("Please Wait, School List Loading");
        progressDialog.setCancelable(false);
        progressDialog.show();
        SchoolDDResponseModel schoolDDUrl = new SchoolDDResponseModel();
        schoolDDUrl.setOp("schoolsdd");
        Call<SchoolDDResponseModel> urlServiceDD = baseUrl.SchoolPostData(schoolDDUrl);
        urlServiceDD.enqueue(new Callback<SchoolDDResponseModel>() {
            @Override
            public void onResponse(Call<SchoolDDResponseModel> call, Response<SchoolDDResponseModel> response) {
                JSONObject jsonObject = null;
                try {
                    if (response.isSuccessful()){
                        SchoolDDResponseModel schooldata = response.body();
                        jsonObject = new JSONObject(new Gson().toJson(response.body()));

                        addItemsOnDD(schooldata.getJ_data());
                    }else {
                        System.out.println("HTTP Service fail :::: "+ response.errorBody());
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<SchoolDDResponseModel> call, Throwable t) {
                System.out.println("HTTP Service Error ::  "+t.getMessage());
                progressDialog.dismiss();
                AlertDialog alertDialog = new AlertDialog.Builder(MainActivity2.this).create();
                alertDialog.setMessage("No Internet");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }
    // add items into Dropdown dynamically
    public void addItemsOnDD(List<SchoolsListModel> schoolsListModelList) {
        final List<String> schoolList = new ArrayList<String>();
        final Map<String, String> schoolMap = new HashMap<String, String>();
        try {
            for (int i = 0; i< schoolsListModelList.size(); i++){
                schoolList.add(schoolsListModelList.get(i).getSchool_name());
                schoolMap.put(schoolsListModelList.get(i).getSchool_id(), schoolsListModelList.get(i).getSchool_name());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //String itemObj =
        schoolListSpinner = (Spinner) findViewById(R.id.etShoolName);
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, schoolList);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        schoolListSpinner.setAdapter(dataAdapter);
        //System.out.println("schoolListSpinner   @@@  "+schoolListSpinner);
        schoolListSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String ddSchoolname = schoolListSpinner.getSelectedItem().toString();

                System.out.println("name ::: "+ddSchoolname);
                for (Map.Entry<String, String> entry : schoolMap.entrySet()){
                    if (Objects.equals(ddSchoolname, entry.getValue())){
                        System.out.println("ENTRY  if :: "+entry.getKey());
                        ddSchoolId = entry.getKey();
                        progressDialog.dismiss();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                System.out.println("NOTHING SELECTED");
            }

        });
    }
    public Double convertVersion(String version) {
        Double convertedVersion = 0.0;

        version = version.replace(".", "");
        String versionAux1 = version.substring(0,1);
        String versionAux2 = version.substring(1, version.length());

        version = versionAux1 + "." + versionAux2;
        convertedVersion = Double.valueOf(version);
        return convertedVersion;
    }
    public boolean dbAppVersion(boolean isLastVersion){

        appVer = BuildConfig.VERSION_NAME;
        final Double deviceVersion = convertVersion(appVer);
        VersionModel vermodel = new VersionModel();
        vermodel.setOp("getVersion");
        Call<VersionModel> versionService = baseUrl.versionPost(vermodel);
        versionService.enqueue(new Callback<VersionModel>() {
            @Override
            public void onResponse(Call<VersionModel> call, Response<VersionModel> response) {
                JSONObject jsonObject = null;
                try {
                    if (response.isSuccessful()){
                        VersionModel version = response.body();
                        System.out.println("App version reponse :: "+version);
                        jsonObject = new JSONObject(new Gson().toJson(response.body()));
                        currentAppVersion = jsonObject.getString("version");
                        Double runningVersion = convertVersion(currentAppVersion);
                        System.out.println("deviceVersion : "+deviceVersion+ "  :: runningVersion ::"+runningVersion);
                        if (runningVersion > deviceVersion) {
                            final boolean isLastVersion = true;
                            System.out.println("isLastVersion @@@ IF "+isLastVersion);
                            Intent i = new Intent(android.content.Intent.ACTION_VIEW);
                            i.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.datalake.StudentTrack"));
                            startActivity(i);
                        }else{
                            final boolean isLastVersion = false;
                            System.out.println("isLastVersion @@@ else "+isLastVersion);
                        }


                    }else {
                        System.out.println("HTTP Service fail :::: "+ response.errorBody());
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<VersionModel> call, Throwable t) {

            }
        });
        return isLastVersion;
       // return currentAppVersion;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("Main activity STARTS @@@");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sp1=this.getSharedPreferences("Login", MODE_PRIVATE);

        Boolean LastVersion = (Boolean) dbAppVersion(isLastVersion);
        System.out.println(" LastVersion @@@ "+LastVersion);

        if (LastVersion.equals(false)){
            System.out.println("MAIN Activity 22");
            String shared_SchoolID=sp1.getString("SchoolID", null);
            String shared_MobileNo = sp1.getString("MobileNo", null);
            String shared_appVer = sp1.getString("App_version", null);
            String shared_tokenno = sp1.getString("Tokenno", null);
            String shared_schoolname = sp1.getString("SchoolName", null);

            if (TextUtils.isEmpty(shared_MobileNo)) {
                getSchoolDD();
                System.out.println("Redirect to Main page");
            }else{
                Bundle b = new Bundle();
                Intent intent = new Intent(MainActivity2.this, ThirdActivity.class);
                b.putString("Pmobile", shared_MobileNo);
                b.putString("Tokenno", shared_tokenno);
                b.putString("SchoolId", shared_SchoolID);
                b.putString("SchoolName", shared_schoolname);
                intent.putExtras(b);
                startActivity(intent);
            }
        }else{

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                    context);
            alertDialogBuilder
                    .setMessage("Please Update App from Google Playstore")
                    .setCancelable(false)
                    .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,int id) {
                            // if this button is clicked, close
                            // current activity
                            //this.Main.finish();
                        }
                    })
                    .setNegativeButton("No",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,int id) {
                            // if this button is clicked, just close
                            // the dialog box and do nothing
                            dialog.cancel();
                        }
                    });

            // create alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();

            // show it
            alertDialog.show();


        }


        TextView versionName = findViewById(R.id.tv_appVersion);
        versionName.setText("Version : " + BuildConfig.VERSION_NAME);


        Registermobile = findViewById(R.id.et_Rmobileno);
        Verify = findViewById(R.id.btn_signin);

        Verify.setEnabled(true);
        Verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String schoolID = ddSchoolId;
                final String schoolName = schoolListSpinner.getSelectedItem().toString();
                final String phoneNo = Registermobile.getText().toString();
                System.out.println("Phone No.   ::: "+phoneNo+ " School ID ::: "+schoolID);

                if (phoneNo == null){
                    System.out.println("Type Null error message");
                }else if(phoneNo.isEmpty()){
                    System.out.println("Type empty error message");
                }else if(phoneNo.trim().length() <= 9){
                    System.out.println("Type length error message");
                }else{

                    validateSignin(String.valueOf(schoolID), phoneNo, String.valueOf(schoolName));
                }
            }
        });
    } //OnCreate function ends here

    /*
    Verify Validation Starts here
     */
    public void validateSignin(final String schooolId, final String mobileno, final String schoolName){
        System.out.println("School :: "+schooolId+"  :: Mobile No ::: "+mobileno);
        VerifyParentResponseModel verifyObj = new VerifyParentResponseModel();
        verifyObj.setOp("verifyMobile");
        verifyObj.setSchool_id(schooolId);
        verifyObj.setP_mobile(mobileno);
        verifyObj.setMsg("");
        //System.out.println("Verify Object ::  "+verifyObj);
        Call<VerifyParentResponseModel> verifyParentService = baseUrl.verifyPost(verifyObj);
        verifyParentService.enqueue(new Callback<VerifyParentResponseModel>() {
            @Override
            public void onResponse(Call<VerifyParentResponseModel> call, Response<VerifyParentResponseModel> response) {
                //System.out.println("VERIFY Response :::: "+response.body().toString());
                if (response.isSuccessful()){
                    VerifyParentResponseModel verifyResponsedata = response.body();
                    try {
                        JSONObject jsonObject = new JSONObject(new Gson().toJson(response.body()));
                        String msgResponse = jsonObject.get("msg").toString();
                        System.out.println("Verify msg:: "+msgResponse);
                        progressDialog = new ProgressDialog(MainActivity2.this);
                        progressDialog.setMessage("Please Wait");
                        progressDialog.setCancelable(false);
                        progressDialog.show();
                        if (msgResponse.equals("validLogin")){
                            System.out.println("Verify JSON Data :: "+jsonObject);

                            Bundle b = new Bundle();
                            Intent intent = new Intent(MainActivity2.this, SecondActivity.class);
                            b.putString("StudentDetails", jsonObject.toString());
                            b.putString("SchoolName", schoolName);
                            b.putString("Pmobile", mobileno);
                            b.putString("SchoolID", schooolId);

                            SharedPreferences sp=getSharedPreferences("Login", MODE_PRIVATE);
                            SharedPreferences.Editor Ed=sp.edit();
                            Ed.putString("SchoolID",schooolId );
                            Ed.putString("MobileNo",mobileno);
                            Ed.putString("App_version",appVer);
                            Ed.putString("SchoolName",schoolName);

                            Ed.commit();

                            intent.putExtras(b);
                            progressDialog.dismiss();
                            startActivity(intent);


                        }else{
                            System.out.println("Invalid Error Msg");
                            AlertDialog alertDialog = new AlertDialog.Builder(MainActivity2.this).create();
                            alertDialog.setTitle("Error Message");
                            alertDialog.setMessage("Please Enter Valid Username and Password");
                            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                            alertDialog.show();
                            progressDialog.dismiss();
                        }
                    } catch (JSONException e) {
                        progressDialog.dismiss();
                        e.printStackTrace();
                    }
                }else{
                    progressDialog.dismiss();
                }

            }

            @Override
            public void onFailure(Call<VerifyParentResponseModel> call, Throwable t) {
                System.out.println("HTTP Service Error ::  "+t.getMessage());
                progressDialog.dismiss();
                AlertDialog alertDialog = new AlertDialog.Builder(MainActivity2.this).create();
                alertDialog.setMessage("No Internet");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }



}
