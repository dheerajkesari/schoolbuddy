package com.dls.busbuddy_v1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.dls.busbuddy_v1.models.GenerateOTPModelResponse;
import com.dls.busbuddy_v1.models.VerifyOTPResponseModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SecondActivity extends AppCompatActivity {

    private TextView Name;
    private TextView ParentMobile;
    private Button GenerateOTP;
    private Button otpVerifyBtn;
    private EditText OtpNumber;
    boolean generateBtnClicked=false;
    public static String OTPNoResponse;
    public static String otpNo;
    public static String SchoolName;


    UrlCallInterface baseUrl = BaseUrlInterface.postBaseUrl.create(com.dls.busbuddy_v1.UrlCallInterface.class);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Name = (TextView) findViewById(R.id.etUname);
        ParentMobile = (TextView) findViewById(R.id.tv_mobileno);
        GenerateOTP = findViewById(R.id.btn_generateOTP);
        OtpNumber = findViewById(R.id.etOtpNo);
        otpVerifyBtn = findViewById(R.id.OtpVerifybtn);

        Bundle bundle = getIntent().getExtras();
        final String StudentDetails = bundle.getString("StudentDetails");
        SchoolName = bundle.getString("SchoolName");
        final String ParentMobileno = bundle.getString("Pmobile");
        final String SchoolID = bundle.getString("SchoolID");

        Name.setText("Welcome to "+String.valueOf(SchoolName));
        ParentMobile.setText("You have Logged in as : "+String.valueOf(ParentMobileno));

        //System.out.println("StudentDetails @@: "+StudentDetails);
        GenerateOTP.setEnabled(true);
        GenerateOTP.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               System.out.println("Generate OTP Button Pressed");
               generateBtnClicked = true;
               if(generateBtnClicked)
               { generateOTP(ParentMobileno, SchoolID);}
               else{
                   System.out.println("Click Generate OTP");
               }
           }
        });



        otpVerifyBtn.setEnabled(true);
        otpVerifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("OTP Btn clicked");
                otpNo = OtpNumber.getText().toString();
                System.out.println("otpVerifyBtn otpNo :: "+otpNo);
                verifyOTP(SchoolID, ParentMobileno, otpNo, StudentDetails);
//                if (otpNo.trim().length() == 6){
//                    FirebaseInstanceId.getInstance().getInstanceId()
//                            .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
//                                @Override
//                                public void onComplete(@NonNull Task<InstanceIdResult> task) {
//                                    if (!task.isSuccessful()) {
//                                        System.out.println("getInstanceId Failed");
//                                        return;
//                                    }
//
//                                    // Get new Instance ID token
//                                    String token = task.getResult().getToken();
//                                    System.out.println("Second Token ::: "+token);
//                                    System.out.println("@@@@@@@@@@@   Redirct to next PAGE     @@@@");
//                                    Bundle b = new Bundle();
//                                    Intent intent = new Intent(SecondActivity.this, ThirdActivity.class);
//                                    b.putString("StudentDetails", StudentDetails);
//
//                                    intent.putExtras(b);
//                                    startActivity(intent);
//                                }
//                            });

//                }else {
//                    System.out.println("Invalid Error Msg");
//                    AlertDialog alertDialog = new AlertDialog.Builder(SecondActivity.this).create();
//                    alertDialog.setMessage("Please enter Valid OTP");
//                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
//                            new DialogInterface.OnClickListener() {
//                                public void onClick(DialogInterface dialog, int which) {
//                                    dialog.dismiss();
//                                }
//                            });
//                    alertDialog.show();
//                }
            }
        });
    }

    public void generateOTP(String p_mobileno, String schooleID ){
        System.out.println("Generate OTP is clicked");
        GenerateOTPModelResponse generateOTPModelResponse = new GenerateOTPModelResponse();
        generateOTPModelResponse.setOp("genOtp");
        generateOTPModelResponse.setMobile_no(p_mobileno);
        generateOTPModelResponse.setSchool_id(schooleID);
        System.out.println("generateOTP generateOTPModelResponse  :: "+generateOTPModelResponse);
        Call<GenerateOTPModelResponse> GenerateURL = baseUrl.GenerateOTPPOST(generateOTPModelResponse);
        GenerateURL.enqueue(new Callback<GenerateOTPModelResponse>() {
            @Override
            public void onResponse(Call<GenerateOTPModelResponse> call, Response<GenerateOTPModelResponse> response) {
                try {
                    JSONObject gResponse = new JSONObject(new Gson().toJson(response.body()));
                    System.out.println("Generate OTP response  @@@  :: "+gResponse);

                    OTPNoResponse = gResponse.getString("otp");
                    System.out.println("OTPNoResponse  @@@  :: "+OTPNoResponse);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<GenerateOTPModelResponse> call, Throwable t) {
                System.out.println("HTTP Service Error ::  "+t.getMessage());
            }
        });
    }

    public void verifyOTP(final String schooleID, final String p_mobileno, String otpResponse, final String StudentDetails){
        System.out.println("@@@@    Verify OTP CLICKed   @@@@");

        VerifyOTPResponseModel verifyOTPResponseModel = new VerifyOTPResponseModel();
        verifyOTPResponseModel.setOp("checkotp");
        verifyOTPResponseModel.setSchool_id(schooleID);
        verifyOTPResponseModel.setMobile_no(p_mobileno);
        verifyOTPResponseModel.setOtp(otpResponse);
        System.out.println("verifyOTP verifyOTPResponseModel  : "+verifyOTPResponseModel.toString());
        Call<VerifyOTPResponseModel> VerifyOTPservice = baseUrl.verifyOTPPost(verifyOTPResponseModel);
        VerifyOTPservice.enqueue(new Callback<VerifyOTPResponseModel>() {
            @Override
            public void onResponse(Call<VerifyOTPResponseModel> call, Response<VerifyOTPResponseModel> response) {
                JSONObject verifyOTPResponse = null;
                try {
                    verifyOTPResponse = new JSONObject(new Gson().toJson(response.body()));
                    System.out.println("Verify OTP Response @@@ :: "+verifyOTPResponse.getString("message"));
                    if (verifyOTPResponse.getString("message").equals("valid")){
                        FirebaseInstanceId.getInstance().getInstanceId()
                            .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                                @Override
                                public void onComplete(@NonNull Task<InstanceIdResult> task) {
                                    if (!task.isSuccessful()) {
                                        System.out.println("getInstanceId Failed");
                                        return;
                                    }else {

                                        String token = task.getResult().getToken();
                                        System.out.println("School Name ::: " + SchoolName);

                                        //sendTokenServer(token);
                                        System.out.println("@@@@@@@@@@@   Redirct to next PAGE     @@@@");
                                        Intent intent = new Intent(SecondActivity.this, ThirdActivity.class);
                                        Bundle b = new Bundle();
                                        b.putString("Pmobile", p_mobileno);
                                        b.putString("SchoolId", schooleID);
                                        b.putString("SchoolName",SchoolName);
                                        b.putString("Tokenno", token);

                                        SharedPreferences sp=getSharedPreferences("Login", MODE_PRIVATE);
                                        SharedPreferences.Editor Ed=sp.edit();
                                        Ed.putString("Tokenno",token);
                                        Ed.commit();

                                        intent.putExtras(b);
                                        startActivity(intent);
                                    }
                                }
                            });
                    }else{
                        AlertDialog alertDialog = new AlertDialog.Builder(SecondActivity.this).create();
                        alertDialog.setMessage("Invalid OTP");
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<VerifyOTPResponseModel> call, Throwable t) {
                System.out.println("HTTP Service Error ::  "+t.getMessage());
                AlertDialog alertDialog = new AlertDialog.Builder(SecondActivity.this).create();
                alertDialog.setMessage("No Internet");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }
    public void sendTokenServer(String tkn){

    }

}
