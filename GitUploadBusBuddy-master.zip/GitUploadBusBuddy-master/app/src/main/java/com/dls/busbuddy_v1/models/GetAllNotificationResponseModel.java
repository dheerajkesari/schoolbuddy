package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetAllNotificationResponseModel {

    @SerializedName("op")
    private String op;

    @SerializedName("school_id")
    private String school_id;

    @SerializedName("p_mobile")
    private String p_mobile;

    @SerializedName("statusCode")
    private String statusCode;

    @SerializedName("message")
    private String message;

    @SerializedName("j_data")
    private List<NotificationDataResponse> j_data;

    public String getOp() {
        return op;
    }

    public void setOp(String op) {
        this.op = op;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getP_mobile() {
        return p_mobile;
    }

    public void setP_mobile(String p_mobile) {
        this.p_mobile = p_mobile;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<NotificationDataResponse> getJ_data() {
        return j_data;
    }

    public void setJ_data(List<NotificationDataResponse> j_data) {
        this.j_data = j_data;
    }

    @Override
    public String toString() {
        return "GetAllNotificationResponseModel{" +
                "op='" + op + '\'' +
                ", school_id='" + school_id + '\'' +
                ", p_mobile='" + p_mobile + '\'' +
                ", statusCode='" + statusCode + '\'' +
                ", message='" + message + '\'' +
                ", j_data=" + j_data +
                '}';
    }
}
