package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

public class StatusMsgModel {

    @SerializedName("statusCode")
    private int statusCode;
    @SerializedName("msg")
    private String msg;
    @SerializedName("op")
    private String op;

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getOp() {
        return op;
    }

    public void setOp(String op) {
        this.op = op;
    }

    @Override
    public String toString() {
        return "StatusMsgModel{" +
                "statusCode=" + statusCode +
                ", msg='" + msg + '\'' +
                ", op='" + op + '\'' +
                '}';
    }
}
