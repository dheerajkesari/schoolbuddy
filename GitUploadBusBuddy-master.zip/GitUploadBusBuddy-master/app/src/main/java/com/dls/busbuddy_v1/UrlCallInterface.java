package com.dls.busbuddy_v1;

import com.dls.busbuddy_v1.models.GenerateOTPModelResponse;
import com.dls.busbuddy_v1.models.GetAllNotificationResponseModel;
import com.dls.busbuddy_v1.models.GetBusLocationResponseModel;
import com.dls.busbuddy_v1.models.GetStudentResponseModel;
import com.dls.busbuddy_v1.models.SchoolDDResponseModel;
import com.dls.busbuddy_v1.models.SetDroppointResponseModel;
import com.dls.busbuddy_v1.models.VerifyOTPResponseModel;
import com.dls.busbuddy_v1.models.VerifyParentResponseModel;
import com.dls.busbuddy_v1.models.VersionModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface UrlCallInterface {
    @POST("/bba/allschools/") Call<SchoolDDResponseModel> SchoolPostData(@Body SchoolDDResponseModel SchoolPostData);
    @POST("/bba/allschools/") Call<VerifyParentResponseModel> verifyPost(@Body VerifyParentResponseModel verifyPost);

    @POST("bba/allschools") Call<GenerateOTPModelResponse> GenerateOTPPOST(@Body GenerateOTPModelResponse GenerateOTPPOST);

    @POST("/bba/allschools/") Call<VerifyOTPResponseModel> verifyOTPPost(@Body VerifyOTPResponseModel verifyOTPPost);

    @POST("/bba/allschools/") Call<GetStudentResponseModel> GetStudentListPost(@Body GetStudentResponseModel GetStudentListPost);

    @POST("/bba/allschools/") Call<GetAllNotificationResponseModel> GetNotificationlListPost(@Body GetAllNotificationResponseModel GetNotificationlListPost);


    @POST("/bba/allschools/") Call<SetDroppointResponseModel> setdropPost(@Body SetDroppointResponseModel setdropPost);

    @POST("/bba/allschools/") Call<GetBusLocationResponseModel> getLocationPost(@Body GetBusLocationResponseModel getLocationPost);

    @POST("/bba/allschools/") Call<VersionModel> versionPost(@Body VersionModel versionPost);

   // @POST("/bba/allschools") Call<SendTokenResponseModel> TokenPost(@Body SendTokenResponseModel TokenPost);


}
