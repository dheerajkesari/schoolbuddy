package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

public class SetDroppointResponseModel {

    @SerializedName("op")
    private String op;
    @SerializedName("school_id")
    private String school_id;
    @SerializedName("student_id")
    private String student_id;
    @SerializedName("user_lat")
    private String user_lat;
    @SerializedName("user_lng")
    private String user_lng;
    @SerializedName("user_landmark")
    private String user_landmark;
    @SerializedName("operation")
    private String operation;
    @SerializedName("msg")
    private String msg;

    public void setOp(String op) {
        this.op = op;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getStudent_id() {
        return student_id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    public String getUser_lat() {
        return user_lat;
    }

    public void setUser_lat(String user_lat) {
        this.user_lat = user_lat;
    }

    public String getUser_lng() {
        return user_lng;
    }

    public void setUser_lng(String user_lng) {
        this.user_lng = user_lng;
    }

    public String getUser_landmark() {
        return user_landmark;
    }

    public void setUser_landmark(String user_landmark) {
        this.user_landmark = user_landmark;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getOp() {
        return op;
    }

    @Override
    public String toString() {
        return "SetDroppointResponseModel{" +
                "op='" + op + '\'' +
                ", school_id='" + school_id + '\'' +
                ", student_id='" + student_id + '\'' +
                ", user_lat='" + user_lat + '\'' +
                ", user_lng='" + user_lng + '\'' +
                ", user_landmark='" + user_landmark + '\'' +
                ", operation='" + operation + '\'' +
                ", msg='" + msg + '\'' +
                '}';
    }
}
