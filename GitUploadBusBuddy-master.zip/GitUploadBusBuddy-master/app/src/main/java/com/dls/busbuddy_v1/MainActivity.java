package com.dls.busbuddy_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import com.dls.busbuddy_v1.models.SchoolDDResponseModel;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText Schoolname;
    private EditText Registermobile;
    private Button Verify;
    private Spinner spinner2;
    ListView list;

    public String getSchoolDD(){
        String schooldd = null;
        UrlCallInterface ourRetrofitDD = BaseUrlInterface.postBaseUrl.create(com.dls.busbuddy_v1.UrlCallInterface.class);
        SchoolDDResponseModel schoolDDUrl = new SchoolDDResponseModel();
        schoolDDUrl.setOp("schoolsdd");
        Call<SchoolDDResponseModel> urlServiceDD = ourRetrofitDD.SchoolPostData(schoolDDUrl);
        urlServiceDD.enqueue(new Callback<SchoolDDResponseModel>() {
            @Override
            public void onResponse(Call<SchoolDDResponseModel> call, Response<SchoolDDResponseModel> response) {
                // System.out.println("Response :::: School L:: "+response.body().toString());
                JSONObject jsonObject = null;
                try {
                    if (response.isSuccessful()){
                        SchoolDDResponseModel schooldata = response.body();
                        jsonObject = new JSONObject(new Gson().toJson(response.body()));
                        System.out.println("JSON Object ::::: "+ jsonObject);
                        System.out.println("School DD  :::: "+ schooldata.getJ_data());
                        //EntityUtils.toString(schooldata.getJ_data());
                        //schooldd = schooldata.getJ_data().toString();
                        //addItemsOnDD(schooldata.toString());

                    }else {
                        System.out.println("HTTP Service fail :::: "+ response.errorBody());
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<SchoolDDResponseModel> call, Throwable t) {
                System.out.println("HTTP Service Error ::  "+t.getMessage());
            }
        });
        return schooldd;
    }
    // add items into Dropdown dynamically
    public void addItemsOnDD(String item) {
        System.out.println(" ###### addItemsOnDD  item ::::  "+item);
        JSONObject jsonObjectResp = null;
        try {
            jsonObjectResp = new JSONObject(item);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //String itemObj =
        //spinner2 = (Spinner) findViewById(R.id.etShoolName);
        List<String> list = new ArrayList<String>();
        list.add("list 1");
        list.add("list 2");
        list.add("list 3");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //addItemsOnDD();
        spinner2 = (Spinner) findViewById(R.id.etShoolName);
        new TheTask().execute();
        Registermobile = findViewById(R.id.et_Rmobileno);
        Verify = findViewById(R.id.btn_signin);

        Verify.setEnabled(true);
        Verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // validateSignin(Schoolname.getText().toString(), Registermobile.getText().toString());
            }
        });

    } //OnCreate function ends here



    class TheTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            String str = null;
            str = getSchoolDD();
            System.out.println("  @@ doInBackground  ::: "+str);
            return str;
        }

        @Override
        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            System.out.println("$$$$$ "+result );
            String response = result.toString();
//            try {
//
//
//                JSONArray new_array = new JSONArray(response);
//
//                for (int i = 0, count = new_array.length(); i < count; i++) {
//                    try {
//                        JSONObject jsonObject = new_array.getJSONObject(i);
//                        title_array.add(jsonObject.getString("title").toString());
//                        notice_array.add(jsonObject.getString("notice").toString());
//
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
//                }
//
//                adapter = new BaseAdapter2(MainActivity.this, title_array, notice_array);
//                list.setAdapter(adapter);
//
//            } catch (JSONException e) {
//                 TODO Auto-generated catch block
//                e.printStackTrace();
//                // tv.setText("error2");
//            }

        }
    }



    /*
    Verify Validation Starts here
     */

    public void validateSignin(String schooolname, String mobileno){
        try {
            if (schooolname.equals("Admin") && mobileno.equals("1234")){
                System.out.println("TRY IF #####");
            }else{
                System.out.println("TRY ELSE #####");
                AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                alertDialog.setTitle("Error Message");
                alertDialog.setMessage("Please Enter Username and Password");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }



}
