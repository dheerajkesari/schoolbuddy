package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

public class GenerateOTPModelResponse {

    @SerializedName("op")
    private String op;
    @SerializedName("school_id")
    private String school_id;
    @SerializedName("mobile_no")
    private String mobile_no;
    @SerializedName("message")
    private String message;
    @SerializedName("otp")
    private String otp;

    public String getOp() {
        return op;
    }

    public void setOp(String op) {
        this.op = op;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getMobile_no() {
        return mobile_no;
    }

    public void setMobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    @Override
    public String toString() {
        return "GenerateOTPModelResponse{" +
                "op='" + op + '\'' +
                ", school_id='" + school_id + '\'' +
                ", mobile_no='" + mobile_no + '\'' +
                ", message='" + message + '\'' +
                ", otp='" + otp + '\'' +
                '}';
    }
}
