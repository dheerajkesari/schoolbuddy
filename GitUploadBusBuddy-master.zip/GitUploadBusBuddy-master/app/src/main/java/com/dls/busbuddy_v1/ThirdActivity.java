package com.dls.busbuddy_v1;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;

import com.dls.busbuddy_v1.models.GetStudentResponseModel;
import com.dls.busbuddy_v1.models.SchoolDDResponseModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThirdActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    public static String ParentMobileNo;
    public static String SchoolId;
    public static String tokenno;
    public static String shlName;
    ProgressDialog progressDialog;
    Cursor cursor;
    protected FrameLayout frameLayout;
    private Toolbar toolbar;
    public EditText TokenNo;
    UrlCallInterface baseUrl = BaseUrlInterface.postBaseUrl.create(com.dls.busbuddy_v1.UrlCallInterface.class);
    final Handler handler = new Handler(Looper.getMainLooper());
    Runnable runnable;

    public void getStudentList(String schoolId, String pMobile){
        progressDialog = new ProgressDialog(ThirdActivity.this);
        progressDialog.setMessage("Please Wait ...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        GetStudentResponseModel getStudentObj = new GetStudentResponseModel();
        getStudentObj.setOp("studentsDataByMobile");
        getStudentObj.setSchool_id(schoolId);
        getStudentObj.setP_mobile(pMobile);
        System.out.println("getStudentObj  before:::: "+getStudentObj);
        Call<GetStudentResponseModel> getListService = baseUrl.GetStudentListPost(getStudentObj);
        getListService.enqueue(new Callback<GetStudentResponseModel>() {
            @Override
            public void onResponse(Call<GetStudentResponseModel> call, Response<GetStudentResponseModel> response) {
                JSONObject jsonObject = null;
                try {
                    if (response.isSuccessful()){
                        //GetStudentResponseModel studentListResponse = response.body();
                        JSONObject studentListResponse = new JSONObject(new Gson().toJson(response.body()));
                        System.out.println("GetStudentResponseModel"+studentListResponse);
                        progressDialog.dismiss();
                       // JSONObject jsonObject = new JSONObject(StudentDetails);
                        String strStudent = studentListResponse.get("data_j").toString();
                        System.out.println("strStudent *** : "+strStudent);
                        JSONArray jsonArr = new JSONArray(strStudent);
                        System.out.println("jsonArr *** : "+jsonArr);
                        addData(jsonArr);
                    }else{
                        System.out.println("Response Failed");
                        progressDialog.dismiss();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<GetStudentResponseModel> call, Throwable t) {
                System.out.println("HTTP Service Error ::  "+t.getMessage());
                progressDialog.dismiss();
                AlertDialog alertDialog = new AlertDialog.Builder(ThirdActivity.this).create();
                alertDialog.setMessage("No Internet");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

//        username = findViewById(R.id.tv_username);
//        System.out.println("Thrid Activity  Loaded   !!!!"+navUsername);


//        username.setText("User : ");
        System.out.println("Thrid Activity  Loaded   !!!!");
        Bundle bundle = getIntent().getExtras();
        final String ParentMobileno = bundle.getString("Pmobile");
        final String tokenno = bundle.getString("Tokenno");
        final String SchoolID = bundle.getString("SchoolId");
        final String SchoolName = bundle.getString("SchoolName");

        SharedPreferences sp=getSharedPreferences("Login", MODE_PRIVATE);
        SharedPreferences.Editor Ed=sp.edit();
        Ed.putString("SchoolName",SchoolName);
        Ed.commit();
        SharedPreferences sp1 = this.getSharedPreferences("Login", MODE_PRIVATE);
        String shared_schoolname = sp1.getString("SchoolName", null);

        System.out.println("ParentMobileno  :: "+ParentMobileno+"   :: SchoolID @@ ::  "+shared_schoolname);
        ParentMobileNo = ParentMobileno;
        SchoolId = SchoolID;
        shlName = shared_schoolname;
        System.out.println("Schoolname @@:: "+shlName);
//        TokenNo = findViewById(R.id.etTokeNo);
//        TokenNo.setText(tokenno);
//        System.out.println("Third Token No     :::: "+tokenno);
        getStudentList(SchoolID, ParentMobileno);

//        ParentNo = (TextView) findViewById(R.id.tvPmobile);
//        ParentNo.setText(ParentMobileno);
        frameLayout = (FrameLayout)findViewById(R.id.container);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        View headerView = navigationView.getHeaderView(0);
        TextView navUsername = (TextView) headerView.findViewById(R.id.tv_username);
        TextView navParentno = (TextView) headerView.findViewById(R.id.tvPmobile);
        navUsername.setText("User : "+ParentMobileno);
        navParentno.setText(shared_schoolname);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }
    /////////////////////////////////
//    public void addHeaders() {
//        TableLayout tl = findViewById(R.id.tbl_table);
//        TableRow tr = new TableRow(this);
//        tr.setLayoutParams(getLayoutParams());
//        tr.addView(getTextView(0, "Name", Color.WHITE, Typeface.BOLD, Color.rgb(22, 119, 72)));
//        tr.addView(getTextView(0, "Set Droppoint", Color.WHITE, Typeface.BOLD, Color.rgb(22, 119, 72)));
//        tr.addView(getTextView(0,  "Action",Color.WHITE, Typeface.BOLD, Color.BLUE));
//        //tr.addView(getTextView(0,  "Track",Color.WHITE, Typeface.BOLD, Color.BLUE));
//        tl.addView(tr, getTblLayoutParams());
//    }

    private TextView getTextView(int id, String title, int color, int typeface, int bgColor,String jsonValue) {
        TextView tv = new TextView(this);
        tv.setId(id);
        tv.setText(title.toUpperCase());

        tv.setTextColor(color);
        tv.setPadding(40, 40, 40, 40);
        tv.setTypeface(Typeface.DEFAULT, typeface);
        tv.setBackgroundColor(bgColor);
        tv.setLayoutParams(getLayoutParams());
        tv.setTag(jsonValue);
        tv.setOnClickListener(this);
        return tv;
    }

    @NonNull
    private TableRow.LayoutParams getLayoutParams() {
        TableRow.LayoutParams params = new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT);
        params.setMargins(2, 0, 0, 2);
        return params;
    }

    @NonNull
    private TableLayout.LayoutParams getTblLayoutParams() {
        return new TableLayout.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT);
    }

    private void addData(JSONArray jsonArr) {
        TableLayout tl = findViewById(R.id.tbl_table);
        try{
            System.out.println("JSON ARY #### :::: "+jsonArr);
            JSONObject jsonObj = null;
            for (int i = 0; i < jsonArr.length(); i++)
            {
                jsonObj = jsonArr.getJSONObject(i);
                System.out.println("JSON OBJ #### :::: "+jsonObj.get("user_lat"));
                TableRow tr = new TableRow(this);
                tr.setLayoutParams(getLayoutParams());
                tr.addView(getTextView(Integer.valueOf(jsonObj.getString("student_id")), jsonObj.getString("f_name")+" "+jsonObj.getString("l_name"),Color.WHITE, Typeface.NORMAL, Color.rgb(22, 119, 72),jsonObj.toString() ));//, jsonObj.toString()
                tr.addView(getTextView(Integer.valueOf(jsonObj.getString("student_id")),"Track",Color.WHITE, Typeface.NORMAL, ContextCompat.getColor(this, R.color.colorAccent),jsonObj.toString() ));
                tl.addView(tr, getTblLayoutParams());
            }

        } catch ( Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public void onClick( View v) {
        int id = v.getId();
        System.out.println("After click ::: "+id);
        TextView tv = findViewById(id);
        if (null != tv) {
            try {
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat formatter1 = new SimpleDateFormat("dd/M/yyyy h:mm");
                Integer getHour = calendar1.get(Calendar.HOUR);
                System.out.println("Curent DATE ### : "+getHour);

                String jobjValue= String.valueOf(v.getTag());
                System.out.println("JSON OBJECT @@@  :"+jobjValue);
                JSONObject jObject = new JSONObject(jobjValue);
                System.out.println("Latitude ::: "+jObject.getString("pay_status"));
                if (jObject.getString("pay_status").equals("1")){





                    Bundle b = new Bundle();
                    Intent intent = new Intent(ThirdActivity.this, TrackActivity.class);
                    b.putString("Pmobile",ParentMobileNo);
                    b.putString("SchoolName",shlName);
                    b.putString("SchoolId",SchoolId);
                    b.putString("Tokenno", tokenno);
                    b.putInt("id",id);
                    b.putString("user_lat", String.valueOf(jObject.getString("user_lat")));
                    b.putString("user_lng", String.valueOf(jObject.getString("user_lng")));
                    if (getHour < 12){
                        b.putString("busIMEI", String.valueOf(jObject.getString("bus_imei_no_m")));
                        System.out.println("Morning Bus");
                    }else{
                        b.putString("busIMEI", String.valueOf(jObject.getString("bus_imei_no_e")));
                        System.out.println("Evening Bus");

                    }
                    intent.putExtras(b);
                    startActivity(intent);
                }else{
                    AlertDialog alertDialog = new AlertDialog.Builder(ThirdActivity.this).create();
                    alertDialog.setMessage("To View this Page, Payment has to be done");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

//            Log.i("onClick", "Clicked on row :: " + id +" ");
//            Toast.makeText(this, "Clicked on row :: " + id + ", Text :: " + tv.getText(), Toast.LENGTH_SHORT).show();
//            Bundle b = new Bundle();
//            Intent intent = new Intent(ThirdActivity.this, TrackActivity.class);
//            b.putInt("id",id);
//            b.putString("user_lat", String.valueOf(17.4466266));
//            b.putString("user_lng", String.valueOf(78.3529642));
//            intent.putExtras(b);
//            startActivity(intent);
        }else {
            AlertDialog alertDialog = new AlertDialog.Builder(ThirdActivity.this).create();
            alertDialog.setMessage("No click on list");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }
    }

    ////////////////////////////////////////////

//    @Override
//    public void onBackPressed() {
//        DrawerLayout drawer = findViewById(R.id.drawer_layout);
//        if (drawer.isDrawerOpen(GravityCompat.START)) {
//            drawer.closeDrawer(GravityCompat.START);
//        } else {
//            super.onBackPressed();
//        }
//    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.third, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
@Override
public void onBackPressed() {
    DrawerLayout drawer = findViewById(R.id.drawer_layout);
    if (drawer.isDrawerOpen(GravityCompat.START)) {
        drawer.closeDrawer(GravityCompat.START);
        // Stop a repeating task like this.
        System.out.println("Back is Press");
        handler.removeCallbacks(runnable);
    } else {
        System.out.println("Back is Pressed");
        handler.removeCallbacks(runnable);
        super.onBackPressed();
    }
}

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        System.out.println("Menu is clicked");
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Bundle b = new Bundle();
            Intent intent = new Intent(ThirdActivity.this, ThirdActivity.class);
            b.putString("Pmobile", ParentMobileNo);
            b.putString("Tokenno", tokenno);
            b.putString("SchoolId", SchoolId);
            b.putString("SchoolName",shlName);
            System.out.println("Third Token no :: "+tokenno);
            intent.putExtras(b);
            startActivity(intent);

        } else if (id == R.id.nav_notification) {
            System.out.println("Notification Hit");

            Bundle b = new Bundle();
            Intent intent = new Intent(ThirdActivity.this, NotificationActivity.class);
            b.putString("Pmobile", ParentMobileNo);
            b.putString("SchoolId", SchoolId);
            b.putString("SchoolName",shlName);
            intent.putExtras(b);
            progressDialog.dismiss();
            startActivity(intent);

        } else if (id == R.id.nav_setting) {
            System.out.println("ParentMobileno  :: "+ParentMobileNo+"   :: SchoolID  ::  "+SchoolId);
            Bundle b = new Bundle();
            Intent intent = new Intent(this, SetlocationActivity.class);
            b.putString("Pmobile", ParentMobileNo);
            b.putString("SchoolId", SchoolId);
            b.putString("SchoolName",shlName);
            intent.putExtras(b);
            progressDialog.dismiss();
            this.startActivity(intent);

        } else if (id == R.id.nav_reset) {
            System.out.println("Reset button clicked");
            Intent intent = new Intent(ThirdActivity.this, MainActivity2.class);
            SharedPreferences sp=getSharedPreferences("Login", MODE_PRIVATE);
            SharedPreferences.Editor Ed=sp.edit();
            Ed.putString("SchoolID",null );
            Ed.putString("MobileNo",null);
            Ed.putString("App_version",null);
            Ed.putString("Tokenno",null);
            Ed.putString("SchoolName",null);
            Ed.commit();
            startActivity(intent);
            finish();
            System.out.println("Reset button FINISHED");

//            SharedPreferences preferences = getSharedPreferences("Login",Context.MODE_PRIVATE);
//            SharedPreferences.Editor editor = preferences.edit();
//            editor.clear();
//            editor.commit();
//            finish();

//            Intent intent = new Intent(this, MainActivity2.class);
//            this.startActivity(intent);
//            Intent mStartActivity = new Intent(this,MainActivity2.class);
//            int mPendingIntentId = 123456;
//            PendingIntent mPendingIntent = PendingIntent.getActivity(this, mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
//            AlarmManager mgr = (AlarmManager)this.getSystemService(Context.ALARM_SERVICE);
//            mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
//            System.exit(0);
        }
        System.out.println("BEFORE MENU LAYOUT");
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        System.out.println("AFTER MENU LAYOUT");
        return true;
    }
}
