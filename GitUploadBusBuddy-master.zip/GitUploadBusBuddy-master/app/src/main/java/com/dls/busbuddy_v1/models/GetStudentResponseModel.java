package com.dls.busbuddy_v1.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetStudentResponseModel {

    @SerializedName("op")
    private String op;
    @SerializedName("school_id")
    private String school_id;
    @SerializedName("p_mobile")
    private String p_mobile;
    @SerializedName("message")
    private String message;
    @SerializedName("parent_type")
    private String parent_type;

    @SerializedName("data_j")
    private List<StudentDataModel> data_j;


    public void setOp(String op) {
        this.op = op;
    }

    public String getOp() {
        return op;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getP_mobile() {
        return p_mobile;
    }

    public void setP_mobile(String p_mobile) {
        this.p_mobile = p_mobile;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getParent_type() {
        return parent_type;
    }

    public void setParent_type(String parent_type) {
        this.parent_type = parent_type;
    }

    public List<StudentDataModel> getData_j() {
        return data_j;
    }

    public void setData_j(List<StudentDataModel> data_j) {
        this.data_j = data_j;
    }

    @Override
    public String toString() {
        return "GetStudentResponseModel{" +
                "op='" + op + '\'' +
                ", school_id='" + school_id + '\'' +
                ", p_mobile='" + p_mobile + '\'' +
                ", message='" + message + '\'' +
                ", parent_type='" + parent_type + '\'' +
                ", data_j=" + data_j +
                '}';
    }
}
